# excalidraw-latex-gen
A firefox extension to automaticaly generate latex on excalidraw
